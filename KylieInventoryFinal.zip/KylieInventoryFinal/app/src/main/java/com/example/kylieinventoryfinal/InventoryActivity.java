package com.example.kylieinventoryfinal;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class InventoryActivity extends Activity {

    private DatabaseHelper db;
    private TableLayout tableLayout;
    private Button buttonAddItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);
        tableLayout = findViewById(R.id.tableInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);

        loadInventoryItems();

        buttonAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryItems();
    }

    private void loadInventoryItems() {
        if (tableLayout.getChildCount() > 1) {
            tableLayout.removeViews(1, tableLayout.getChildCount() - 1);
        }

        Cursor cursor = db.getAllItems();

        if (cursor == null) {
            Toast.makeText(this, "Error loading inventory", Toast.LENGTH_SHORT).show();
            return;
        }

        if (cursor.getCount() == 0) {
            Toast.makeText(this, getString(R.string.no_items), Toast.LENGTH_SHORT).show();
        }

        while (cursor.moveToNext()) {
            int itemId = cursor.getInt(0);
            String itemName = cursor.getString(1);
            int quantity = cursor.getInt(3);

            TableRow row = new TableRow(this);

            TextView nameView = new TextView(this);
            nameView.setText(itemName);
            nameView.setPadding(8, 8, 8, 8);

            TextView quantityView = new TextView(this);
            quantityView.setText(String.valueOf(quantity));
            quantityView.setPadding(8, 8, 8, 8);

            Button updateButton = new Button(this);
            updateButton.setText(getString(R.string.plus_one));
            updateButton.setOnClickListener(v -> {
                boolean updated = db.updateItemQuantity(itemId, quantity + 1);
                if (updated) {
                    Toast.makeText(InventoryActivity.this, getString(R.string.quantity_updated), Toast.LENGTH_SHORT).show();
                    loadInventoryItems();
                }
            });

            Button deleteButton = new Button(this);
            deleteButton.setText(getString(R.string.delete));
            deleteButton.setOnClickListener(v -> {
                boolean deleted = db.deleteItem(itemId);
                if (deleted) {
                    Toast.makeText(InventoryActivity.this, getString(R.string.item_deleted), Toast.LENGTH_SHORT).show();
                    loadInventoryItems();
                }
            });

            row.addView(nameView);
            row.addView(quantityView);
            row.addView(updateButton);
            row.addView(deleteButton);

            tableLayout.addView(row);
        }

        cursor.close();
    }
}
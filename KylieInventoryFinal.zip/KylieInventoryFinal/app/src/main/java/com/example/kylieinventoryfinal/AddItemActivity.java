package com.example.kylieinventoryfinal;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends Activity {

    private EditText editItemName;
    private EditText editCategory;
    private EditText editQuantity;
    private Button buttonSaveItem;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        editItemName = findViewById(R.id.editItemName);
        editCategory = findViewById(R.id.editCategory);
        editQuantity = findViewById(R.id.editQuantity);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);

        db = new DatabaseHelper(this);

        buttonSaveItem.setOnClickListener(v -> {
            String itemName = editItemName.getText().toString().trim();
            String category = editCategory.getText().toString().trim();
            String quantityText = editQuantity.getText().toString().trim();

            if (itemName.isEmpty() || category.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(AddItemActivity.this, "Enter all fields", Toast.LENGTH_LONG).show();
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException e) {
                Toast.makeText(AddItemActivity.this, "Enter a valid number", Toast.LENGTH_LONG).show();
                return;
            }

            boolean inserted = db.insertItem(itemName, category, quantity);

            if (inserted) {
                Toast.makeText(AddItemActivity.this, "Item added successfully", Toast.LENGTH_LONG).show();
                editItemName.setText("");
                editCategory.setText("");
                editQuantity.setText("");
            } else {
                Toast.makeText(AddItemActivity.this, "Error adding item", Toast.LENGTH_LONG).show();
            }
        });
    }
}